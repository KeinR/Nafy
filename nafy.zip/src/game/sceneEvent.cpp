#include "sceneEvent.h"

#include "Scene.h"
#include "../core/Context.h"

nafy::sceneEvent::~sceneEvent() {
}
