#ifndef FTYPE_WRAPPER_H_INCLUDED
#define FTYPE_WRAPPER_H_INCLUDED

#include <ft2build.h>
#include FT_FREETYPE_H

#endif
