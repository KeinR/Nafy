#ifndef GLFW_WRAPPER_H_INCLUDED
#define GLFW_WRAPPER_H_INCLUDED

// A simple wrapper to ensure that the glfw header gets included correctly

#define GLFW_DLL
#include <glad/glad.h>
#include <GLFW/glfw3.h>

#endif
