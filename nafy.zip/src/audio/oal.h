#ifndef OPENAL_WRAPPER_H_INCLUDED
#define OPENAL_WRAPPER_H_INCLUDED

#include <AL/alc.h>
#include <AL/al.h>

#endif
