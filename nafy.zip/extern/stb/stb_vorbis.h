#define STB_VORBIS_HEADER_ONLY
// It's not what it seems - it's a little weird how this one is structured...
// It's the reverse of his other APIs
#include "stb_vorbis.c"
